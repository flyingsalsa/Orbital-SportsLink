// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth"; 
import { getFirestore } from "firebase/firestore";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDHE1tT2LXXt9kqaqWEEIGLH8ZwViKLhKg",
  authDomain: "sportslink-504d3.firebaseapp.com",
  databaseURL: "https://sportslink-504d3-default-rtdb.firebaseio.com",
  projectId: "sportslink-504d3",
  storageBucket: "sportslink-504d3.appspot.com",
  messagingSenderId: "280685909276",
  appId: "1:280685909276:web:b6a1f9e5145bc5b96fd6d9",
  measurementId: "G-J2KMGBSXJR"
};

// Initialize Firebase
export const FB_APP = initializeApp(firebaseConfig);
export const FB_AUTH = getAuth(FB_APP);
const FB_ANA = getAnalytics(FB_APP);
export const db = getFirestore(FB_APP);