import { View, Text } from 'react-native'
import React from 'react'

const Notifications = () => {
  return (
    <View style={{backgroundColor: '#FDBD21',flex:1}}>
      <Text>WIP</Text>
    </View>
  )
}

export default Notifications